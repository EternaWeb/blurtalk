
<header>
<a href="index.php">
    <img src="Untitled (93).png" alt="Blur Logo" class="logoi">
</a>
    <button onclick="window.location.href='form.php'">
        <i class="bi bi-plus-circle-dotted"></i>
    </button>
    </header>

    <style>

        .logoi {
            width: 60px;
            height: 60px;
            position: center;
        }

        </style>